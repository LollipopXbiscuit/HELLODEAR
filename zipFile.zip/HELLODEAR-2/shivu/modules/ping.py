import time

from telegram import Update
from telegram.ext import CommandHandler, CallbackContext

from shivu import application, sudo_users

async def ping(update: Update, context: CallbackContext) -> None:
    user_id = str(update.effective_user.id)
    if user_id not in sudo_users:
        await update.message.reply_text(f"Nouu.. its Sudo user's Command..\nYour ID: {user_id}")
        return
    start_time = time.time()
    message = await update.message.reply_text('Pong!')
    end_time = time.time()
    elapsed_time = round((end_time - start_time) * 1000, 3)
    await message.edit_text(f'Pong! {elapsed_time}ms')

application.add_handler(CommandHandler("ping", ping))
